import pathlib
import re
import xmltodict
from lxml import etree
import logging


class Xml:
    def __init__(self,src):
        logging.info('Creating new Xml class')

        with open(str(src), 'rb') as fd:
            self.doc = xmltodict.parse(fd.read())

        with open(str(src), 'rb') as f:
            self.tree = etree.parse(f)
            self.root = self.tree.getroot()

    def getProjects(self,regex):
        projects = {}
        for child in self.root:
        #print(child.tag)
            if child.tag == 'projects':
                project = child
                attributes = project.attrib
                if re.compile(regex).match(attributes['name']):
                    ntqaProject = {}
                    ntqaProject['name'] = attributes['name']
                    for name, value in sorted(project.items()):
                        #print('%s = %r' % (name, value))
                        ntqaProject.update({name:value})
                    
                    #for name, value in ntqaProject:
                    #    print(f'{name} = {value}')
                        

                    print(ntqaProject['name'])
                    projects.update({attributes['name']:ntqaProject})
#                    for child in project:
#                        print(child.tag)
#                        print(attributes['name'])
#                        print(attributes['nativeId'])
#                        print(attributes['key'])
#                        print(attributes['lead'])
#                        print(attributes['issueTypeScheme'])
#                        print(attributes['workflowScheme'])
#                        print(attributes['screenScheme'])
#                        print(attributes['fieldScheme'])
#                        print(attributes['permissionScheme'])
#                        print(attributes['notificationScheme'])
#                        print(attributes['priorityScheme'])
#        for projects in self.root: # composer is an element in the xml file.
#            print('Found project')
#            children = projects.getchildren() # Children nodes are composers data
#            data = map(lambda child: (child.tag, child.text),
#                    children)
           # print('Data: {}'.format(dict(data)))

        return projects

if __name__ == '__main__':
    pass
