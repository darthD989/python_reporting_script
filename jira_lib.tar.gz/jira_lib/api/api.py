import doctest
from jira import JIRA, JIRAError
import requests
import json

#requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.insecureRequest.warning)
class JiraException(Exception):
    pass

class Jira(object):

    __client = None

    def __init__(self, options, dict):

        """converting to oauth
            >>> jira = Jira(username='testUser', password='testUser')
        """

        try:
            self.__client = JIRA(options, oauth=dict)
        except:
            raise JiraException('Could not connect to the API, something happened during oauth') from None

    def getProjects(self, raw = False):
        Projects = []
        for project in self.__client.projects():
            if raw:
                Projects.append(project)
            else:
                Projects.append({'id':project.id, 'Name':project.key, 'Description':project.name })
        return Projects

    def getProject(self, key):
        """Gets one project
            >>> jira = Jira(username='testUser', password='testUser')
            >>> jira.getProject('TEST')
            <JIRA Project: key='TEST', name='test', id='10000'>
        """
        project = self.__client.project(key)
        return project
    
    def runJql(self,jql_str):
        """runs a single jql query
            >>> jira = Jira(username='testUser', password='testUser')
            >>> jira.runJql(f"project in (TEST) AND issuetype in (Bug) ORDER BY updated DESC")
            [<JIRA Issue: key='TEST-1', id='10004'>]
        """

        results = self.__client.search_issues(jql_str, startAt=0, maxResults=2000, validate_query=True, fields=None, expand=None, json_result=None)
        return results

    def addComment(self,issue,comment):
        """adds a comment to an existing issue
            >>> jira = Jira(username='testUser', password='testUser')
            >>> issue = "TEST-1"
            >>> comment = f"{issue} Comment Test"
            >>> jira.addComment(issue, comment)
        """
        self.__client.add_comment(issue,comment)

# No unit tests have been written for methods below this line.

    def getProjectIssues(self, key):
        issues_in_proj = self.__client.search_issues('project=' + key)
        return issues_in_proj

    def createProject(self,project):
        key = project[0]
        name = project[1]
        assignee = project[2] 
        type = project[3]
        try:
            create_project = self.__client.create_project(key, name, assignee, type)
            print(f"Created {key} Successfully")
        except ValueError:
            print(create_project)
        except ValueError as e:
            print(f"Did Not Create {key} Successfully!!!!!\n{e}\n\n")
            return "didn't create project"
        except JIRAError as e:    
            print(f"{e}")
            create_project = e
        return create_project

    def createProjects(self,projects):
        for project in projects: 
            self.createProject(project)

    def deleteProject(self,project):
        key = project[0]
        try:
            delete_project = self.__client.delete_project(key)
            print(f"Deleted {key} Successfully")
        except ValueError as e:
            print(f"Did Not Delete {key} Successfully!!!!!\n{e}\n\n")
            return "didn't delete project"
        except JIRAError as e:    
            print(f"{e}")
            delete_project = e
        return delete_project

    def deleteProjects(self,projects):
        for project in projects: 
            self.deleteProject(project)
    def getIssues(self, maxResults = 10, raw = False, **kwargs):
        Issues = [] 
        if len(kwargs) < 1:
            raise JiraException('You need to specify search criteria')
        else:
            searchstring = ' '.join([(_ + "=" + kwargs[_]) if _ != 'condition' else kwargs[_] for _ in kwargs])
            for item in self.__client.search_issues(searchstring, maxResults = maxResults):        
                if raw:
                    Issues.append(item)
                else:
                    Issues.append({'Assignee':item.fields.assignee,'TimeSpent':item.fields.timespent,'CreateDate':item.fields.created,'DueDate':item.fields.duedate})
        return Issues
    def getIssue(self,key):
        get_issue = self.__client.issue(key)
        return get_issue
    def createIssue(self,hash):
        new_issue = self.__client.create_issue(fields=hash)
        return new_issue
    def getIssueType(self,id):
        type = self.__client.issue_type(id)
        return type
    def updateIssue(self,issue,hash):
        update_issue = issue.update(fields=hash)
        return update_issue
    def deleteIssue(self,issue):
        delete = issue.delete()
        return delete
    def createCustomField(self):
        payload = json.dumps( {
          "name": "New custom field",
          "description": "Custom field for picking groups",
          "type": "com.atlassian.jira.plugin.system.customfieldtypes:grouppicker",
          "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:grouppickersearcher"
           } )
        headers = {
          "Accept": "application/json",
          "Content-Type": "application/json",
          "Bearer": "<access_token>"
          }

        url = self.__options
        response = requests.request(
          "POST",
          url,
          data=payload,
          headers=headers
          )

        print(json.dumps(json.loads(response.text), sort_keys=True, indent=4, separators=(",", ": ")))

if __name__ == '__main__':
    import doctest
    count, _ = doctest.testmod()
    if count == 0:
        print('*** ALL TESTS PASS ***')
