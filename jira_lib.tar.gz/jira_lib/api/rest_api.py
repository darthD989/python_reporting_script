import requests
import json

def _url(path):    
    return 'http://dc2jiraappdv01.it.savvis.net:8080' + path 

if __name__ == '__main__':
    print(_url("HI"))

    auth = ('ac05604', '')

    headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Bearer": "<access_token>"
            }

    payload = json.dumps( {
            "name": "New custom field",
            "description": "Custom field for picking groups",
            "type": "com.atlassian.jira.plugin.system.customfieldtypes:grouppicker",
            "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:grouppickersearcher"
            } )
    r = requests.get('http://dc2jiraappdv01.it.savvis.net:8080/user', auth=('ac05604', '2aLuvaB1eDaddE29'))
    print(r)
#'http://dc2jiraappdv01.it.savvis.net:8080'

    r = requests.get("http://dc2jiraappdv01.it.savvis.net:8080/rest/api/2/field")
#    print(r.json())
#    r = requests.post("http://localhost:8080/rest/api/2/field", data = payload)
    print(r.text)
#    r = requests.request(
#               "POST",
#                url,
#                data=payload,
#                )

    #print(json.dumps(json.loads(r.text), sort_keys=True, indent=4, separators=(",", ": ")))
