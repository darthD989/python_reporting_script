from lib.api import Jira
import re

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    jira = Jira(username='testUser', password='testUser')

    projects = [
        ["NTQAACCESS", "NTQA Access", "ndirden", "software"],
        ["NTQAACCRG","NTQA Access RG",  "assignee"],
        ["NTQABUCK", "NTQA Buckley", "ndirden"],
        ["NTQAEVS","NTQA Enterprise VoIP Solutionas", "assignee"],
        ["NTQAETH","NTQA Ethernet", "assignee"],
        ["NTQAINTER", "NTQA Internet",  "assignee"],
        ["NTQAMEDIA", "NTQA Media", "assignee"],	
        ["NTQAOPSEN", "NTQA Operations Enablement", "assignee"],
        ["NTQAADMN", "NTQA Project Admin","assignee"],
        ["NTQASDNNFV", "NTQA SDN/NFV", "assignee"],
        ["NTQATSTLAB", "NTQA Test Lab", "assignee"],
        ["NTQATR", "NTQA Test Request","assignee"],
        ["NTQATXTEST", "NTQA Transport Test","assignee"],
        ["NTQAVCS", "NTQA VoIP Core Solutions", "assignee"],
        ["NTQAVPN", "NTQA VPN", "assignee"],
        ["NTQAWIRLSS", "NTQA Wireless","assignee"],
    ]

    for project in projects: 
        newProject = jira.createProject(project)

#    for project in projects: 
#        deleteProject = jira.deleteProject(project)

